import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { supabase } from './supabase';
import { ShoppingBag, Store, User, LogOut, Search, Plus, ShieldCheck, Package, ClipboardList, Menu, X } from 'lucide-react';
import './style.css';

const BANK = { name: 'First Bank', account: '3216809728', holder: 'Oladeji Peace Simeon' };
const money = n => `₦${Number(n || 0).toLocaleString('en-NG')}`;
const categories = ['Fashion','Electronics','Home & Living','Beauty','Food','Phones & Accessories','Books','Sports','Other'];

function App() {
  const [session,setSession] = useState(null), [profile,setProfile] = useState(null);
  const [page,setPage] = useState('home'), [products,setProducts] = useState([]), [stores,setStores] = useState([]);
  const [cart,setCart] = useState([]), [search,setSearch] = useState(''), [busy,setBusy] = useState(false), [notice,setNotice] = useState('');
  const [authMode,setAuthMode] = useState('login'), [auth,setAuth] = useState({email:'',password:'',full_name:'',phone:''});
  const [productForm,setProductForm] = useState({name:'',description:'',price:'',category:'Fashion',stock:'1'});
  const [storeForm,setStoreForm] = useState({store_name:'',description:'',category:'Other',contact_phone:''});
  const [checkout,setCheckout] = useState({phone:'',address:'',reference:''});
  const [orders,setOrders] = useState([]);

  useEffect(()=> {
    if (!supabase) return;
    supabase.auth.getSession().then(({data})=>setSession(data.session));
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_e,s)=>setSession(s));
    return ()=>subscription.unsubscribe();
  },[]);
  useEffect(()=>{ if(session) loadProfile(); else {setProfile(null); loadProducts();} },[session]);
  useEffect(()=>{ loadProducts(); loadStores(); },[]);
  useEffect(()=>{ if(profile) loadOrders(); },[profile]);

  async function loadProfile() {
    const {data,error}=await supabase.from('profiles').select('*').eq('id',session.user.id).maybeSingle();
    if(error) setNotice(error.message);
    setProfile(data);
  }
  async function loadProducts() {
    if(!supabase) return;
    const {data,error}=await supabase.from('products').select('*').eq('status','approved').order('created_at',{ascending:false});
    if(!error) setProducts(data||[]);
  }
  async function loadStores() {
    if(!supabase) return;
    const {data}=await supabase.from('stores').select('*').eq('status','approved');
    setStores(data||[]);
  }
  async function loadOrders() {
    if(!supabase || !session) return;
    let q=supabase.from('orders').select('*').order('created_at',{ascending:false});
    if(profile?.role!=='admin') q=q.eq('customer_id',session.user.id);
    const {data}=await q; setOrders(data||[]);
  }
  async function signIn(e) {
    e.preventDefault(); setBusy(true); setNotice('');
    const fn=authMode==='login'
      ? supabase.auth.signInWithPassword({email:auth.email,password:auth.password})
      : supabase.auth.signUp({email:auth.email,password:auth.password,options:{data:{full_name:auth.full_name,phone:auth.phone}}});
    const {error}=await fn; setNotice(error ? error.message : (authMode==='login'?'Signed in.':'Account created. Check your email if confirmation is enabled.'));
    setBusy(false);
  }
  async function signOut(){await supabase.auth.signOut();setPage('home');}
  async function becomeVendor(e) {
    e.preventDefault(); if(!session) return setPage('auth');
    setBusy(true);
    const {error}=await supabase.from('stores').insert({...storeForm,owner_id:session.user.id,status:'pending'});
    setNotice(error?error.message:'Store application submitted for admin approval.'); setBusy(false);
  }
  async function addProduct(e) {
    e.preventDefault(); if(!session) return setPage('auth');
    const myStore=stores.find(s=>s.owner_id===session.user.id);
    if(!myStore) return setNotice('You need an approved store before adding products.');
    const {error}=await supabase.from('products').insert({ ...productForm, price:Number(productForm.price),stock:Number(productForm.stock),store_id:myStore.id,status:'pending' });
    setNotice(error?error.message:'Product submitted for approval.'); setBusy(false);
  }
  function addToCart(p){setCart(c=>[...c,p]);setNotice('Added to cart.');}
  async function placeOrder(e) {
    e.preventDefault();
    if(!session) return setPage('auth');
    if(!cart.length) return;
    setBusy(true); setNotice('');
    const total=cart.reduce((s,p)=>s+Number(p.price||0),0);
    const {data:order,error}=await supabase.from('orders').insert({
      customer_id:session.user.id,total_amount:total,status:'pending_payment',
      payment_method:'bank_transfer',payment_status:'awaiting_verification',
      delivery_address:checkout.address,customer_phone:checkout.phone,
      payment_reference:checkout.reference
    }).select().single();
    if(error){setNotice(error.message);setBusy(false);return;}
    const rows=cart.map(p=>({order_id:order.id,product_id:p.id,quantity:1,unit_price:Number(p.price||0)}));
    const {error:itemError}=await supabase.from('order_items').insert(rows);
    setNotice(itemError?`Order created, but items need attention: ${itemError.message}`:'Order placed. Transfer payment and submit your transaction reference. Admin verification is required.');
    setCart([]); setBusy(false); loadOrders(); setPage('orders');
  }
  async function adminUpdate(table,id,values) {
    const {error}=await supabase.from(table).update(values).eq('id',id);
    setNotice(error?error.message:'Updated successfully.');
    if(table==='stores') loadStores(); if(table==='products') loadProducts(); loadOrders();
  }

  if(!supabase) return <main className="setup"><h1>Kings& Queen</h1><h2>Connect your Supabase project</h2><p>Create a <code>.env</code> file using <code>.env.example</code> and add your Supabase Project URL and Publishable Key. Never use a secret/service-role key in browser code.</p></main>;
  const visible=products.filter(p=>`${p.name||p.title||''} ${p.description||''} ${p.category||''}`.toLowerCase().includes(search.toLowerCase()));
  const total=cart.reduce((s,p)=>s+Number(p.price||0),0);
  const isAdmin=profile?.role==='admin';
  return <div>
    <header><a className="brand" onClick={()=>setPage('home')}>KINGS<span>&</span> QUEEN <small>MARKETPLACE</small></a><div className="nav">
      <button onClick={()=>setPage('home')}>Shop</button><button onClick={()=>setPage('vendor')}>Become a vendor</button>
      {session&&<><button onClick={()=>setPage('orders')}>My orders</button>{isAdmin&&<button onClick={()=>setPage('admin')}>Admin</button>}<button onClick={()=>setPage('account')}>Account</button><button onClick={signOut}><LogOut size={16}/> Sign out</button></>}
      {!session&&<button onClick={()=>setPage('auth')}>Login / Register</button>}
      <button className="cartbtn" onClick={()=>setPage('cart')}><ShoppingBag size={17}/> Cart ({cart.length})</button>
    </div></header>
    <section className="hero"><div><p className="eyebrow">A MARKETPLACE FOR EVERYONE</p><h1>Discover more.<br/><em>Shop with confidence.</em></h1><p>Shop products from independent stores and growing businesses.</p><button className="gold" onClick={()=>document.getElementById('products')?.scrollIntoView({behavior:'smooth'})}>Explore products</button></div></section>
    {notice&&<div className="notice" onClick={()=>setNotice('')}>{notice} <b>×</b></div>}
    <main>
      {page==='home'&&<><div className="sectionhead" id="products"><div><p className="eyebrow">THE COLLECTION</p><h2>Shop products</h2></div><label className="search"><Search size={18}/><input placeholder="Search products..." value={search} onChange={e=>setSearch(e.target.value)}/></label></div>
      <div className="grid">{visible.map(p=><article className="product" key={p.id}><div className="productpic"><Package size={38}/></div><p className="tag">{p.category||'Marketplace'}</p><h3>{p.name||p.title||'Product'}</h3><p className="muted">{p.description||''}</p><div className="productbottom"><b>{money(p.price)}</b><button onClick={()=>addToCart(p)}><Plus size={16}/> Add</button></div></article>)}</div>{!visible.length&&<p className="empty">No approved products yet. Products will appear here after vendors list them and an admin approves them.</p>}</>}
      {page==='auth'&&<section className="panel narrow"><h2>{authMode==='login'?'Welcome back':'Create your account'}</h2><div className="tabs"><button onClick={()=>setAuthMode('login')}>Login</button><button onClick={()=>setAuthMode('signup')}>Register</button></div><form onSubmit={signIn}>{authMode==='signup'&&<><input required placeholder="Full name" value={auth.full_name} onChange={e=>setAuth({...auth,full_name:e.target.value})}/><input placeholder="Phone number" value={auth.phone} onChange={e=>setAuth({...auth,phone:e.target.value})}/></>}<input required type="email" placeholder="Email" value={auth.email} onChange={e=>setAuth({...auth,email:e.target.value})}/><input required type="password" placeholder="Password" value={auth.password} onChange={e=>setAuth({...auth,password:e.target.value})}/><button className="gold" disabled={busy}>{busy?'Please wait...':authMode==='login'?'Login':'Create account'}</button></form></section>}
      {page==='vendor'&&<section className="panel narrow"><h2>Open your store</h2><p className="muted">Submit your store for admin approval. You can list products after approval.</p><form onSubmit={becomeVendor}><input required placeholder="Store name" value={storeForm.store_name} onChange={e=>setStoreForm({...storeForm,store_name:e.target.value})}/><textarea placeholder="Store description" value={storeForm.description} onChange={e=>setStoreForm({...storeForm,description:e.target.value})}/><select value={storeForm.category} onChange={e=>setStoreForm({...storeForm,category:e.target.value})}>{categories.map(c=><option>{c}</option>)}</select><input placeholder="Contact phone" value={storeForm.contact_phone} onChange={e=>setStoreForm({...storeForm,contact_phone:e.target.value})}/><button className="gold">Submit store</button></form></section>}
      {page==='account'&&<section className="panel"><h2>My account</h2><p>{session?.user.email}</p><p>Role: {profile?.role||'customer'}</p><h3>My stores</h3>{stores.filter(s=>s.owner_id===session?.user.id).map(s=><p>{s.store_name} — {s.status}</p>)}<h3>Add a product</h3><form className="formgrid" onSubmit={addProduct}><input required placeholder="Product name" value={productForm.name} onChange={e=>setProductForm({...productForm,name:e.target.value})}/><input required type="number" min="0" placeholder="Price (₦)" value={productForm.price} onChange={e=>setProductForm({...productForm,price:e.target.value})}/><select value={productForm.category} onChange={e=>setProductForm({...productForm,category:e.target.value})}>{categories.map(c=><option>{c}</option>)}</select><input type="number" min="0" placeholder="Stock" value={productForm.stock} onChange={e=>setProductForm({...productForm,stock:e.target.value})}/><textarea placeholder="Description" value={productForm.description} onChange={e=>setProductForm({...productForm,description:e.target.value})}/><button className="gold">Submit product</button></form></section>}
      {page==='cart'&&<section className="panel"><h2>Your cart</h2>{cart.map((p,i)=><div className="line" key={i}><span>{p.name||p.title} — {money(p.price)}</span><button onClick={()=>setCart(cart.filter((_,j)=>i!==j))}>Remove</button></div>)}<h3>Total: {money(total)}</h3>{cart.length>0&&<><div className="bank"><b>Bank transfer details</b><p>{BANK.name} · {BANK.holder}</p><strong>{BANK.account}</strong><p>Transfer the exact amount. Your order remains unconfirmed until an admin verifies payment.</p></div><form className="narrow" onSubmit={placeOrder}><input required placeholder="Delivery address" value={checkout.address} onChange={e=>setCheckout({...checkout,address:e.target.value})}/><input required placeholder="Your phone number" value={checkout.phone} onChange={e=>setCheckout({...checkout,phone:e.target.value})}/><input placeholder="Transfer reference (if already paid)" value={checkout.reference} onChange={e=>setCheckout({...checkout,reference:e.target.value})}/><button className="gold" disabled={busy}>Place bank-transfer order</button></form></>}</section>}
      {page==='orders'&&<section className="panel"><h2>{isAdmin?'All orders':'My orders'}</h2>{orders.map(o=><div className="line"><span>Order {String(o.id).slice(0,8)} · {money(o.total_amount)} · {o.status} · Payment: {o.payment_status}</span>{isAdmin&&<button onClick={()=>adminUpdate('orders',o.id,{payment_status:'verified',status:'processing'})}>Verify payment</button>}</div>)}</section>}
      {page==='admin'&&isAdmin&&<section className="panel"><h2><ShieldCheck/> Admin dashboard</h2><h3>Store applications</h3>{stores.filter(s=>s.status==='pending').map(s=><div className="line"><span>{s.store_name} — {s.owner_id}</span><div><button onClick={()=>adminUpdate('stores',s.id,{status:'approved'})}>Approve</button><button onClick={()=>adminUpdate('stores',s.id,{status:'rejected'})}>Reject</button></div></div>)}<h3>Products pending approval</h3>{products.filter(p=>p.status==='pending').map(p=><div className="line"><span>{p.name||p.title}</span><button onClick={()=>adminUpdate('products',p.id,{status:'approved'})}>Approve</button></div>)}<p className="muted">For secure payment verification and commission reporting, complete the SQL setup and admin policies in README before launch.</p></section>}
    </main>
    <footer><b>Kings& Queen</b><p>Shop confidently. Support growing businesses.</p><small>Bank transfer: First Bank · {BANK.holder} · {BANK.account}</small><p className="muted">Paystack payments will be added in a later release.</p></footer>
  </div>;
}
createRoot(document.getElementById('root')).render(<App/>);
