# Kings& Queen Marketplace — starter release

This is a Vite + React + Supabase starter project. It includes customer authentication, store application submission, product listing submission, product browsing, a basic cart, bank-transfer checkout, and a basic admin view.

## Important before launch

This starter is **not yet production-ready**. The SQL below is a compatibility baseline, not a guarantee that it matches every existing table you created earlier. Back up your database first and inspect existing columns. The app expects these columns:

- `profiles`: `id`, `full_name`, `phone`, `role`, `created_at`
- `stores`: `id`, `owner_id`, `store_name`, `description`, `category`, `contact_phone`, `status`, `created_at`, `updated_at`
- `products`: `id`, `store_id`, `name`, `description`, `price`, `category`, `stock`, `status`, `created_at`
- `orders`: `id`, `customer_id`, `total_amount`, `status`, `payment_method`, `payment_status`, `delivery_address`, `customer_phone`, `payment_reference`, `created_at`
- `order_items`: `id`, `order_id`, `product_id`, `quantity`, `unit_price`

If your products/orders columns differ, the app needs adapting before use. The checkout code does not yet handle stock reservation, shipping, refunds, or secure server-side commission settlement.

## 1. Local setup

1. Install Node.js on a computer, or use a browser-based development environment that supports Vite.
2. Extract this ZIP.
3. Copy `.env.example` to `.env`.
4. Put your Supabase Project URL and **Publishable key** in `.env`:
   - `VITE_SUPABASE_URL=https://brzzamsgdhssswrdngcy.supabase.co`
   - `VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_KEY`
5. Never put an `sb_secret_...` key or `service_role` key in `.env` for this frontend.
6. Run `npm install`, then `npm run dev`; build with `npm run build`.

## 2. Admin account

Register your own account through the site first. Then, in Supabase SQL Editor, run the following using the exact email you registered with (replace the sample email). This grants admin role to that account. Keep the admin account secure and do not expose admin credentials.

```sql
UPDATE public.profiles p
SET role = 'admin'
FROM auth.users u
WHERE p.id = u.id
  AND u.email = 'YOUR-LOGIN-EMAIL@example.com';
```

Do not provide a public "make me admin" button. Only a trusted project owner should run this SQL.

## 3. Bank-transfer details

The checkout currently displays:
- First Bank
- Account name: Oladeji Peace Simeon
- Account number: 3216809728

Before launch, confirm that the account belongs to the marketplace operator and that you are comfortable displaying it publicly. Paystack is not enabled in this release.

## 4. Supabase security

Enable Row Level Security on every exposed table and create policies that restrict:
- Customers to their own profile and orders.
- Vendors to their own stores and products.
- Only admins to approve stores/products and verify payments.
- Public users to read only approved stores/products.

Do not launch with unrestricted write policies. The admin buttons in this starter rely on database policies; without correct RLS, they should fail rather than be treated as secure. For a production launch, move payment verification and commission calculations to a trusted server/Edge Function and verify payment evidence manually.

## 5. Netlify

Build command: `npm run build`
Publish directory: `dist`

In Netlify, add the same two environment variables (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`) under Site configuration → Environment variables, then redeploy. Configure Supabase Authentication → URL Configuration with your deployed Netlify site URL and allowed redirect URLs.

## Known limitations in this starter

- Product images and receipt uploads are not implemented yet.
- Bank transfer is manually verified; there is no automatic bank confirmation.
- Paystack integration is intentionally deferred.
- Commission percentage and payout logic must be agreed and implemented server-side before accepting real transactions.
- The code assumes the column names listed above. Check your existing schema before deploying.
